package com.example.maze;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaDataSource;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;

public class startActivity extends AppCompatActivity {

    Button musicBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
        MediaPlayer mPlayer = MediaPlayer.create(startActivity.this, R.raw.medley);

       musicBtn = findViewById(R.id.musicBtn);

        musicBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                if(!mPlayer.isPlaying()){
                    mPlayer.start();
                    musicBtn.setText("Sound off");
                }
                else{
                    mPlayer.stop();
                    musicBtn.setText("Sound on");
                }
            }
        });

    }

    public void startGame(View view){
        Intent i = new Intent(startActivity.this, MainActivity.class);
        startActivity(i);

    }



}