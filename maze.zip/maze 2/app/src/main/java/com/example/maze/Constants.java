package com.example.maze;

import android.content.Context;

public class Constants {
    public static int SCREEN_WIDTH;
    public static int SCREEN_HEIGHT;
    public static long INIT_TIME;

    public static Context CURRENT_CONTEXT;

}
